export interface CommonOptionsPropertyRange {
	id: number;
	valuetype: 'ParamRange';
	min: number;
	max: number;
	value: number;
}
