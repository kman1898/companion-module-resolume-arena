export interface CommonOptionsPropertyChoice {
	id: number;
	valuetype: 'ParamChoice';
	value: string;
	index: number;
	options: string[];
}
