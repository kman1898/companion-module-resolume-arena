export interface CommonOptionsPropertyString {
	id: number;
	valuetype: 'ParamString';
	value: string;
}
