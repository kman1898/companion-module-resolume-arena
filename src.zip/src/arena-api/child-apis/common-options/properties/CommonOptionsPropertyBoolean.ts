export interface CommonOptionsPropertyBoolean {
	id?: number;
	valuetype?: 'ParamBoolean';
	value: boolean;
}
